import React, {Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as Actions from '../actions/index';
import DataGradleVersion from '../utils/demo.json';
import prepareDependencies from '../utils/prepareDep';
import DependenciesList from '../components/DependenciesList';
import SearchInput from "../components/SearchInput";
import DependenciesModal from "./DependenciesModal";

class Search extends Component {

    constructor(props) {
        super(props);
        this.props.actions.getGradleVersion(DataGradleVersion);
    }


    generateResultData(selectedName) {
        const packages = prepareDependencies(DataGradleVersion, selectedName);
        const numberOfPackages = packages.length;
        this.props.actions.setupRequests(numberOfPackages, DataGradleVersion, selectedName);
        packages.forEach((value) => this.props.actions.fetchPackageDetails(value));
        this.props.actions.openModal();

    }


    render() {

        return (
            <div className="interface">
                <SearchInput/>
                <DependenciesList
                    modules={this.props.gradleList}
                    onModuleNameSelect={selectedName => this.generateResultData({selectedName})}/>
                <DependenciesModal modalIsOpenApp={this.props.modalOpenMap}
                                   onRequestClose={() => this.props.actions.closeModal()}/>
                <button
                    className="btn btn-success btn-large btn-block"
                    onClick={() => this.generateDemoData()}>
                    <i className="fa fa-play" aria-hidden="true"/>
                    Demo
                </button>
            </div>
        )

    }
}

function mapStateToProps(state) {
    return {
        gradleList: state.gradleRoot.dataRd,
        modalOpenMap: state.modalRoot.modalIsOpenRd,
        resultMap: state.resultRoot
    };
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(Actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Search);
