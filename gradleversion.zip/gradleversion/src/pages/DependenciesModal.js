import React, {Component} from 'react';
import Modal from 'react-modal';
import {connect} from 'react-redux';
import * as Actions from '../actions/index';
import {bindActionCreators} from 'redux';
import Package from './Package';

class DependenciesModal extends Component {


    getInfoDependencies(pack) {
        const upToDate = pack.filter((pkg) => pkg.packageStatus.isUpToDate).size;
        const outToDate = pack.filter((pkg) => pkg.packageStatus.isOutToDate).size;

        console.log("up ", upToDate);
        return {
            upToDate,
            outToDate
        }
    }


    render() {

        //this.props.resultMap.get('response').forEach((pkg, i) => console.log("XUXA" ,pkg, i));

        Object.keys(this.props.resultMap.name).map((pk,i) => {
        console.log("POL", this.props.resultMap.name[pk], pk, i)
        });

        const dependencies = this.props.resultMap.name.map((pk,i) => {
            console.log("DEXP ", pk, i)
        });



        return (

            <Modal
                isOpen={this.props.modalIsOpenApp}
                contentLabel="Modal"
                onRequestClose={() => this.props.actions.closeModal()}>
                <div className="h1">
                    <p>{this.props.projectMap.name} {this.props.projectMap.version} {this.props.projectMap.number}</p>
                </div>

                <div className="container packages">
                    <div className="row">

                    </div>
                </div>
            </Modal>
        )
    }
}

function mapStateToProps(state) {
    return {
        projectMap: state.projectRoot,
        resultMap: state.resultRoot,
        modalOpenMap: state.modalRoot.modalIsOpenRd
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(Actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(DependenciesModal)
