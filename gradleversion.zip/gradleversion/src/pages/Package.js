import React from 'react';

export default class Package extends React.Component {



    render() {
        let readme;

        const { name, payload, requiredVersion } = this.props.details;
        //const latestVersion = payload.hasOwnProperty('dist-tags') ? payload['dist-tags'].latest : '-';



        return (
            <div className="row package">
                <div className="col-sm-1 col-md-12 status">
                </div>
                <div className="col-sm-5 col-md-12 name">
                    <small>name</small> {name} {readme}
                </div>
                <div className="col-sm-3 col-md-6 required">
                    <small>required</small><span> {requiredVersion}</span>
                </div>

            </div>
        );
    }
};
