import React from 'react'
import DependenciesItem from "./DepedenciesItem";

const DependenciesList = (props) => {
    const filter = props.modules;

    const moduleVersionList = Object.keys(filter).map((item, index) => {

        return <DependenciesItem key={index}
                                 module={filter[item]}
                                 onModuleNameList={props.onModuleNameSelect}
        />
    });
    return (
        <ul className="item-list media-list">
            {moduleVersionList}
        </ul>
    )
};

export default DependenciesList;
