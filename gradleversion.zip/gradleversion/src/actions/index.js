import prepareNameModule from "../utils/prepareModule";
import demoData from "../utils/demo.json";
import {compareVersionNumbers, getStatus} from '../utils/versionStatus';
import request from 'superagent'

export const SETUP_REQUESTS = 'SETUP_REQUESTS';
export const FETCH_PACKAGE_REQUEST = 'FETCH_PACKAGE_REQUEST'; //Revision
export const FETCH_PACKAGE_SUCCESS = 'FETCH_PACKAGE_SUCCESS'; //FETCH GRADLE VERSION
export const GET_GRADLE_VERSION = 'GET_GRADLE_VERSION';
export const OPEN_MODAL = 'OPEN_MODAL';
export const CLOSE_MODAL = 'CLOSE_MODAL';

const API_DATA = demoData;

export function setupRequests(numberOfPackages, payload, mod) {
    //console.log("REVISAR ACTION");
    //console.log("Module Name - Version : ", numberOfPackages, payload, "Mod : ",  mod);

    return {
        type: SETUP_REQUESTS,
        numberOfPackages: numberOfPackages,
        projectName: payload[mod.selectedName].name,
        version: payload[mod.selectedName].version
    };
}

export function fetchPackageSuccess(name, requiredVersion, packageStatus, demoData) {
    return {
        type: FETCH_PACKAGE_SUCCESS,
        name,
        requiredVersion,
        packageStatus,
        demoData
    };
}

export function fetchPackageRequest() {
    return {
        type: FETCH_PACKAGE_REQUEST
    }
}

export function fetchPackageDetails(packageDetails) {
    const {name, requiredVersion} = packageDetails;

    return (dispatch) => {
        dispatch(fetchPackageRequest());
        //const {moduleName} = module;
        console.log("PackageDetails", name, requiredVersion);

        const mod = prepareNameModule(API_DATA, name);

        if (mod !== undefined) {
            console.log("MODULE ", mod["0"].name, mod["0"].version);

            const checkStatus = compareVersionNumbers(requiredVersion, mod[0].version);
            console.log("CheckStatus : ", checkStatus);
            const packageStatus = getStatus(checkStatus);
            console.log("PackageStatus : ", packageStatus);
            dispatch(fetchPackageSuccess(name, requiredVersion, packageStatus, mod[0].version));
        }

    };
}

export function getGradleVersion(demoData) {
    const data = request.get(demoData);

    return {
        type: GET_GRADLE_VERSION,
        payload: data.url
    }

}

export function openModal() {
    return {
        type: OPEN_MODAL,
    }
}

export function closeModal() {
    return {
        type: CLOSE_MODAL,
    }
}
