import {FETCH_PACKAGE_SUCCESS} from '../actions'
import {List, Map} from 'immutable';

const initialState = {
    response: List(),
    isFetching: false,
    name: []
};

export default function reducer(state = initialState, action) {

    switch (action.type) {
        case FETCH_PACKAGE_SUCCESS :

            return {
                ...state,
                name: action.name,
                requiredVersion: action.requiredVersion,
                packageStatus: action.packageStatus,
                demoData: action.demoData,
                isFetching: true
            };


        default:
            return state;
    }

}