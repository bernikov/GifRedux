import {combineReducers} from 'redux';
import gradleVersion from './gradle'
import modal from './modal';
import result from './result';
import project from './project';

const rootReducers = combineReducers({
    projectRoot: project,
    resultRoot: result,
    gradleRoot: gradleVersion,
    modalRoot: modal
});

export default rootReducers;
