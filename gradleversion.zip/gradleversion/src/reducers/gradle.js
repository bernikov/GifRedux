import {GET_GRADLE_VERSION} from "../actions";

const initialState =  {
    dataRd: [],
};

export default function versions(state = initialState, action) {

    switch (action.type) {
        case GET_GRADLE_VERSION :
            return {
                ...state,
                dataRd: action.payload,
                error: null
            };
        default :
            return state;
    }
}