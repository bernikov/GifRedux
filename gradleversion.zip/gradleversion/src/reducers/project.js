import {Map, List} from 'immutable';

import {
    SETUP_REQUESTS
} from '../actions';

const initialState = Map({
    isFetching: false,
    name: null,
    version: null,
    error: null,
    response: List()
});

export default function reducer(state = initialState, action) {
    switch (action.type) {
        case SETUP_REQUESTS:
            console.log("ACTION", action.projectName);
            return {
                ...state,
                isFetching : false,
                number: action.numberOfPackages,
                name: action.projectName,
                version: action.version,
                error: null
            };
        default:
            return state;
    }
};
