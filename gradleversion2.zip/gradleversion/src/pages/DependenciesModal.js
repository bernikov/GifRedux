import React, {Component} from 'react';
import Modal from 'react-modal';
import {connect} from 'react-redux';
import * as Actions from '../actions/index';
import {bindActionCreators} from 'redux';
import Package from './Package';

class DependenciesModal extends Component {

    constructor(props) {
        super(props);
        //this.getInfo()
    }

    componentWillUnmount() {
        this.props.resultMap = [];
    }

    getInfo() {
        const resultObject = this.props.resultMap.map((pk, i) => {
            console.log("NOMAR", this.props.resultMap);

            return {
                name: this.props.resultMap[pk].name,
                requiredVersion: this.props.resultMap[pk].requiredVersion,
                packageStatus: this.props.resultMap[pk].packageStatus,
                realVersion: this.props.resultMap[pk].demoData
            };

        });

        console.log("XUXA ", resultObject);
    }
    //this.props.resultMap.map((pkg, i)

    getInfoDependencies(pack) {
        console.log("PACK" , pack);
        const upToDate = pack.filter((pkg) => console.log("FILTERPACK ", pkg));
        //const outToDate = pack.filter((pkg) => pkg.packageStatus.isOutToDate).size;

        console.log("up ", upToDate);
        return {
            upToDate,
            //outToDate
        }
    }


    render() {

        return (

            <div>
                <Modal
                    isOpen={this.props.modalIsOpenApp}
                    contentLabel="Modal"
                    onRequestClose={() => this.props.actions.closeModal()}>
                    <div className="h1">
                        <p>{this.props.projectMap.name} {this.props.projectMap.version} {this.props.projectMap.number}</p>
                    </div>

                    <div className="container packages">
                        <div className="row">

                        </div>
                    </div>
                    <Package details={this.props.resultMap}/>

                </Modal>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        projectMap: state.projectRoot,
        resultMap: state.resultRoot,
        modalOpenMap: state.modalRoot.modalIsOpenRd
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(Actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(DependenciesModal)
