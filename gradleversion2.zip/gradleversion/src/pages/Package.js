import React from 'react';


const Package = ({details}) => {


    const generalDepend = Object.keys(details).map((pk) => {
        return {
            name : details[pk].name,
            version : details[pk].requiredVersion,
            required : details[pk].demoData,
            packageStatus : details[pk].packageStatus,
        }
    });

    function getStats(packages) {
        const upToDate = packages.filter((pkg) => pkg.packageStatus.isUpToDate).length;
        const outToDate = packages.filter((pkg) => pkg.packageStatus.isOutToDate).length;

        return {
            upToDate,
            outToDate
        }
    }


    const filterUndefiend = generalDepend.filter((pkg) =>  pkg.name);

    const dependenciesStats = getStats(filterUndefiend);

    return (
        <div className="col-sm-2 stats-map">
            <small>dependencies</small>
            <div className="uptodate">
                Up to date: {dependenciesStats.upToDate}
            </div>
            <div className="minor-updates">
                Out To date: {dependenciesStats.outToDate}
            </div>
            <div className="col-sm-12">
            </div>

        </div>
    );




};

export default Package;