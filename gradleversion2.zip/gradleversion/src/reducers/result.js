import {FETCH_PACKAGE_SUCCESS} from '../actions'
import {List, Map} from 'immutable';
import {CLOSE_MODAL} from "../actions/index";

const initialState = Map ({
    isFetching: false,
    resultDependencies: List()
});

export default function reducer(state = initialState, action) {

    console.log("REDUCERX", action);
    switch (action.type) {
        case FETCH_PACKAGE_SUCCESS :
            const resultDependencies = {
                name: action.name,
                requiredVersion: action.requiredVersion,
                packageStatus: action.packageStatus,
                demoData: action.demoData,


            };
            return [
                ...state, resultDependencies
            ];

        case CLOSE_MODAL :
            return initialState;

        default:
            return state;
    }

}