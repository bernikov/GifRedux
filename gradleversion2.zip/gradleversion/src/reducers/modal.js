import {OPEN_MODAL, CLOSE_MODAL} from "../actions/index";

const initialState = {
    modalIsOpenRd: false,
};

export default function modal(state = initialState, action) {
    console.log("Modal Action REDUCER  : ", action);

    switch (action.type) {
        case OPEN_MODAL :
            return {
                ...state,
                modalIsOpenRd: true
            };

        case CLOSE_MODAL :
            return {
                ...state,
                modalIsOpenRd: false
            };
        default:
            return state;

    }
}