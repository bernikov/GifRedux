export default {

    API_URL: '',
    CHART_OPTIONS: {
        percentageInnerCutout : 35,
        segmentShowStroke : false,
        responsive: true
    }

};
