export default function prepareModule(module, nameModule) {
  if (module[nameModule] !== undefined) {
    const module2 = Object.keys(module[nameModule]).map(function (key, item) {
      console.log("KEY :", key, module[nameModule].source, module[nameModule].version);

      return {
        name: module[nameModule].source,
        version: module[nameModule].version
      };
    });
    return {
      ...module2
    };
  }
};
