export default function prepareDependenciesData(packageJson, module) {
    console.log("MODULE ", module);
    if (module !== undefined) {
        const dependencies = Object.keys(packageJson[module.selectedName].dependencies).map(function (key) {
                console.log("PREPARE DATA");
                console.log("Modulo - Version - Dependencies: ",
                    packageJson[module.selectedName].dependencies[key].name,
                    packageJson[module.selectedName].dependencies[key].dep);
                console.log("=========================================");
                return {
                    name: packageJson[module.selectedName].dependencies[key].name,
                    requiredVersion: packageJson[module.selectedName].dependencies[key].dep,
                    isDependency: true
                };
            }
        );

        return [
            ...dependencies
        ];
    }
};
