import React from 'react';

const DependenciesItem = ({module, onModuleNameList, index}) => {
  return (

    <li className="pet-item media">
      <div className="media-left">
        <button onClick={() => onModuleNameList(module.source)}
                className="pet-delete btn btn-xs btn-success">
          <span className="glyphicon glyphicon-ok"/></button>
      </div>
      <div className="pet-info media-body">
        <div className="pet-head">
          <a onClick={() => onModuleNameList(module.source)}>{module.name} - <span>{module.version}</span></a>
        </div>
      </div>
    </li>

  )
};

export default DependenciesItem;
