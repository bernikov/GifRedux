import React, {Component} from 'react';
import './App.css';
import Home from './pages/Home';

class App extends Component {
  render() {
    return (
      <div>
        <div className="App-header">
          <h2>Modules</h2>
        </div>
        <Home/>
      </div>
    );
  }
}

export default App;
