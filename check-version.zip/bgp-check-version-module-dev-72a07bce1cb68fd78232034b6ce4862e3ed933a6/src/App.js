import React, { Component } from 'react';
import './App.css';
import Search from './components/search';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <h2>Gradle Version</h2>
        </div>
        <p className="App-intro">
          Obtener version
        </p>
        <Search />
      </div>
    );
  }
}

export default App;
