import { Map } from 'immutable';

import {
  SETUP_REQUESTS
} from '../actions';

const initialState = Map({
  name: null,
  version: null,
  error: null
});

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case SETUP_REQUESTS:
      //console.log("ACTION" , action.projectName);
      return state
        .set('name', action.projectName)
        .set('version', action.version)
        .set('error', null);
    default:
      return state;
  }
};
