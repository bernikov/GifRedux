import {combineReducers} from 'redux';
import project from './project';

export default combineReducers({
  project
});
