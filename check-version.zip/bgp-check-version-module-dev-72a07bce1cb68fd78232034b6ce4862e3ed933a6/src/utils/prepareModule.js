export default function prepareModule(module, nameModule) {

  if (module[nameModule] !== undefined) {
    const module2 = Object.keys(module[nameModule].version).map(function (key) {
      //console.log("KEY :", key, module[nameModule].version[key]);

      return {
        name: key,
        version: module[nameModule].version[key]
      };

    });
    return {
      ...module2
    };
  }
};
