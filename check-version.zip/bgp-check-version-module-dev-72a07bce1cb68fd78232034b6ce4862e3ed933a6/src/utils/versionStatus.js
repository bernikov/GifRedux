export function compareVersionNumbers(v1, v2) {

  //console.log("VERSION : ", v1, v2);
  var running_version = v1;
  var lastest_version = v2;

  if (running_version < lastest_version) {
    //Version necesita update
    return -1;
  } else if (running_version === lastest_version) {
    return 1;
  }
}

export function getStatus(status) {
  let isUpToDate = false;
  let isOutToDate = false;

  if (status === -1) {
    isOutToDate = true;
  } else {
    isUpToDate = true;
  }

  return {
    isUpToDate,
    isOutToDate
  }
}
