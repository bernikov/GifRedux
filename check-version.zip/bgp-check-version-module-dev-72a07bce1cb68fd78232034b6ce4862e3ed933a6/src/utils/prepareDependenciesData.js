export default function prepareDependenciesData(packageJson, module) {
  const dependencies = Object.keys(packageJson[module].dependencies).map(function (key) {
      console.log("PREPARE DATA");
      console.log("Modulo - Version - Dependencies: ", key, packageJson[module].dependencies[key]);
      console.log("=========================================");
      return {
        name: key,
        requiredVersion: packageJson[module].dependencies[key],
        isDependency: true
      };
    }
  );

  return [
    ...dependencies
  ];
};
