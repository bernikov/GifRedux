import React, {Component} from 'react';
import {connect} from 'react-redux';
import {setupRequests, fetchPackageDetails} from '../actions';
import DataGradleVersion from '../utils/demo.json';
import prepareDependenciesData from '../utils/prepareDependenciesData';


class Search extends Component {

  constructor(props) {
    super(props);
    this.state =
      {}
  }

  generateDemoData() {
    const packages = prepareDependenciesData(DataGradleVersion, 'com.bgeneral.bel.account.api');
    const numberOfPackages = packages.length;
    this.props.setupRequests(numberOfPackages, DataGradleVersion, 'com.bgeneral.bel.account.api');
    packages.forEach((value) => this.props.fetchPackageDetails(value));

  }


  render() {
    return (
      <div>
        <button
          className="btn btn-success btn-large btn-block"
          onClick={() => this.generateDemoData()}>
          <i className="fa fa-play" aria-hidden="true"/>
          Demo
        </button>
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    project: state.project
  };
}

export default connect(mapStateToProps, {setupRequests, fetchPackageDetails})(Search);
