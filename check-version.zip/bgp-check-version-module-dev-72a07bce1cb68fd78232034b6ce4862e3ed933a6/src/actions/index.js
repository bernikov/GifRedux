import prepareNameModule from "../utils/prepareModule";
import demoData from "../utils/demo.json";
import {compareVersionNumbers, getStatus} from '../utils/versionStatus';

export const SETUP_REQUESTS = 'SETUP_REQUESTS';
export const FETCH_PACKAGE_REQUEST = 'FETCH_PACKAGE_REQUEST';
export const FETCH_PACKAGE_SUCCESS = 'FETCH_PACKAGE_SUCCESS';

export function setupRequests(numberOfPackages, payload, mod) {
  console.log("REVISAR ACTION");
  //console.log("Module Name - Version : ", payload[mod].name, payload[mod].version, payload[mod]);

  return {
    type: SETUP_REQUESTS,
    numberOfPackages,
    projectName: payload[mod].name,
    version: payload[mod].version
  };
}

export function fetchPackageRequest() {
  return {
    type: FETCH_PACKAGE_REQUEST
  };
}

export function fetchPackageSuccess() {
  return {
    type: FETCH_PACKAGE_SUCCESS
  }
}

export function fetchPackageDetails(packageDetails) {
  const {name, requiredVersion} = packageDetails;

  return (dispatch) => {
    dispatch(fetchPackageRequest());
    //const {moduleName} = module;
    console.log("PackageDetails", name, requiredVersion);

    const mod = prepareNameModule(demoData, name);

    if (mod !== undefined) {
      console.log("MODULE ", mod["0"].name, mod["0"].version);

      const checkStatus = compareVersionNumbers(requiredVersion, mod[0].version);
      console.log("CheckStatus : ", checkStatus);
      const packageStatus = getStatus(checkStatus);
      console.log("PackageStatus : ", packageStatus);
      dispatch(fetchPackageSuccess(name, requiredVersion, packageStatus, demoData));
    }

  };
}
